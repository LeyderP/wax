package wax.wax.Dominio.excepciones;

public class FechaInvalida extends RuntimeException {
    public FechaInvalida(String message) {
        super(message);
    }
}