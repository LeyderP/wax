package wax.wax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
